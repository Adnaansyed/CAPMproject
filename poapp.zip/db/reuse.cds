 
namespace poapp.reuse ;
 
using { Currency } from '@sap/cds/common';
 
 
 
// Reusable Custom Types
type Guid : UUID ;
type PhoneNumber : String(32);
type Email : String(255);
type Role : String(2);
type String32 : String(32);
type String255 : String(255);
 
// Enumerator
type Gender : String(1) enum {
    male = 'M' ;
    female = 'F' ;
    undisclosed = 'U' ;
} ;
 
// Resuable Type for Amount
type AmountT : Decimal(10,2) @(
    Semantics.amount.currencyCode : 'CURRENCY_CODE',
    sap.unit : 'CURRENCY_CODE'
);
 
aspect Amount {
    CURRENCY : Currency ;
    GROSS_AMOUNT : AmountT ;
    NET_AMOUNT : AmountT ;
    TAX_AMOUNT : AmountT ;
}
 
aspect Address {
    STREET : String(255);
    POSTAL : String(12);
    CITY : String(255);
    COUNTRY : String(255);
    BUILDING : String(255);
}