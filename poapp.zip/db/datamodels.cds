namespace poapp.db;

using { Currency, cuid } from '@sap/cds/common';
 
using { poapp.reuse as reuse } from './reuse';
 
context master {
    entity BusinessPartners {
        key NODE_KEY : reuse.Guid;
        BP_ROLE : reuse.Role;
        EMAIL : reuse.Email;
        MOBILE : reuse.PhoneNumber;
        FAX : reuse.String32;
        WEB : reuse.String255;
        BP_ID : reuse.Guid;
        COMPANY_NAME : reuse.String255;
 
        ADDRESS_GUID : Association to Addresses;
    }
 
    entity Addresses : reuse.Address {
        key NODE_KEY : reuse.Guid ;
        ADDRESS_TYPE : reuse.String32;
        VAL_START : Date ;
        VAL_END : Date ;
        LATITUDE : Decimal ;
        LONGITUDE : Decimal ;
 
        // Association - Unmanaged
        businesspartner : Association to one BusinessPartners on businesspartner.ADDRESS_GUID = $self ;
    }
 
    entity Products {
        key NODE_KEY : reuse.Guid ;
        PRODUCT_ID : reuse.String32 ;
        TYPE_CODE : String(2);
        CATEGORY : reuse.String32 ;
        DESCRIPTION : reuse.String255 ;
        TAX_TARIF_CODE : Integer ;
        MEASURE_UNIT : String(2);
        WEIGHT_MEASURE : Decimal(15,2);
        WEIGHT_UNIT : String(2);
        PRICE : Decimal(15,2);
        CURRENCY_CODE : String(4);
        WIDTH : Decimal(5,2);
        DEPTH : Decimal(5,2);
        HEIGHT : Decimal(5,2);
        DIM_UNIT : String(2);
 
        // Managed Association
        SUPPLIER_GUID : Association to BusinessPartners ;
    }
 
    entity Employees : cuid {
        nameFirst : String(40);
        nameLast : String(40);
        nameInitials : String(40);
        nameMiddle : String(40);
        gender : reuse.Gender ;
        language : String(2);
        loginName : String(16);
        phoneNumber : reuse.PhoneNumber ;
        email : reuse.Email ;
        Currency : Currency ;
        salaryAmount : reuse.AmountT;
        accountNumber : String(16);
        bankId : String(16);
        bankName : String(64);
    }
}
 
context transaction {
    entity PurchaseOrders : reuse.Amount {
        key NODE_KEY : reuse.Guid ;
        PO_ID : reuse.Guid ;
        // Association - Managed
        PARTNER_GUID : Association to master.BusinessPartners ;
 
        LIFECYCLE_STATUS : String(1);
        OVERALL_STATUS : String(1);
 
        // Association - Unmanaged
        Items : Association to many PurhcaseItems on Items.PARENT_KEY = $self ;
    }
 
    entity PurhcaseItems : reuse.Amount {
        key NODE_KEY : reuse.Guid ;
        PARENT_KEY : Association to PurchaseOrders ;
        PO_ITEMS_POS : Integer ;
 
        // Association - Managed
        PRODUCT_GUID : Association to master.Products ;
    }
}
