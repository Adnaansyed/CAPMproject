module.exports = cds.service.impl( async function(){
    // Step-1 : Get the employee object from the service entities
    let { EmployeeSrv } = this.entities;
 
    // Step-2 : Implment the logic to get the highest salary employee details
    this.on('gethighestSalary', async(request, response) => {
        try{
            // Step-3 : Create an object for the transaction
            const tx = cds.tx(request);
 
            // Step-4 : Get salary of an employee using Transaction object
            const response = await tx.read(EmployeeSrv).orderBy({
                salaryAmount : 'desc'
            }).limit(10);
 
            // Step-5 : Return the response
            return response;
        } catch(error) {
            return "Error : " + error;
        }
    })
});