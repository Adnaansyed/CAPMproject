using { poapp.db as database  } from '../db/datamodels';
 
service MyService {
 
    entity ProductSrv as projection on database.master.Products;
 
    entity BusinessPartnerSrv as  projection on database.master.BusinessPartners;
 
    entity AddressesSrv as projection on database.master.Addresses;
 
    entity EmployeeSrv as projection on database.master.Employees;
 
    entity PurchaseOrderSrv as projection on database.transaction.PurchaseOrders;
 
    entity PurhcaseItemSrv as projection on database.transaction.PurhcaseItems;
    
    // Declaration of Function - function <function_name> ( <parameters> ) returns <return_type>;
    function gethighestSalary() returns array of EmployeeSrv;
 
}